---
name: screen-residential-mailboxes
description: Collect Anytime Mailbox United States location listings and screen them for residential addresses using matching Smarty and Firstlogic evidence. Use when a user asks to find, continue finding, verify, filter, or export residential virtual-mailbox addresses, especially when CMRA must be N and RDI must indicate residential.
---

# Screen Residential Mailboxes

Find public Anytime Mailbox locations, verify each candidate with Smarty and Firstlogic, and return only addresses that both services identify as residential and not CMRA.

## Required rule

An address qualifies only when all four predicates are true:

- Smarty `RDI` is `Residential`.
- Smarty `CMRA` is `N`.
- Firstlogic `RDI` is `Y`, `R`, or `Residential`.
- Firstlogic `CMRA` is `N`.

Do not use USPS as a condition unless the user explicitly adds it. Do not infer a pass from a map, building appearance, zoning, or only one provider.

## Workflow

1. Confirm the requested scope and number of results. If omitted, use all U.S. state pages and the requested result count from the conversation.
2. Run `scripts/collect-anytime-mailbox.ps1` to create or resume the source listing CSV. Preserve the source detail URL for every address.
3. Before submitting any address to Smarty, Firstlogic, or another third party, tell the user which services will receive the addresses and obtain explicit confirmation. A prior confirmation in the same conversation is sufficient for the stated services and scope.
4. Validate candidates with the public interactive pages in a browser, or with documented APIs and credentials supplied by the user. Never embed, discover, reuse, or redistribute demo keys, cookies, session tokens, or private endpoints.
5. Record every completed response in separate Smarty and Firstlogic evidence CSVs using `references/result-schema.md`. Save after every lookup so a run can resume.
6. Run `scripts/filter-verified-results.ps1` to produce the final CSV. Return only double-confirmed rows and show the exact evidence columns.
7. Report the result count, output path, source URLs, and any addresses still pending because of rate limits, CAPTCHA, downtime, or ambiguous responses.

## Browser validation

When interactive validation is needed, use the Browser skill and read its `SKILL.md` before operating the browser. Use:

- Smarty Single Address: `https://www.smarty.com/products/single-address`
- Firstlogic Verify Address: `https://firstlogic.com/tools/verify-address`

Enter one source address at a time and capture the displayed RDI and CMRA values. If a result is hidden, ambiguous, or requires a challenge, mark it pending rather than guessing.

## Reliability and safety

- Respect rate limits, CAPTCHAs, terms, and access restrictions. Never bypass a challenge or rotate identities to evade limits.
- Cache completed lookups and resume from existing evidence. Do not query an address again when the evidence is complete unless the user asks for a refresh.
- Treat HTTP 429, timeout, network failure, CAPTCHA, and site downtime as temporary/pending. Do not record them as an address failure.
- Keep raw evidence or a concise timestamped transcription sufficient to audit each pass.
- Do not include local query history, previously found addresses, credentials, or cookies when sharing this skill.
- Do not claim that a result proves the address is a private home. It only satisfies the two providers' RDI/CMRA classifications at lookup time.

## Commands

Collect or resume source listings:

```powershell
& "$PSScriptRoot/scripts/collect-anytime-mailbox.ps1" -OutputPath ./anytime-locations.csv -CacheDirectory ./collection-cache
```

Filter completed evidence:

```powershell
& "$PSScriptRoot/scripts/filter-verified-results.ps1" `
  -LocationsPath ./anytime-locations.csv `
  -SmartyEvidencePath ./smarty-evidence.csv `
  -FirstlogicEvidencePath ./firstlogic-evidence.csv `
  -OutputPath ./residential-addresses.csv
```

Read `references/result-schema.md` before creating evidence files. Both scripts support `-SelfTest` and require no network for the self-test.
