# Result schema

Use UTF-8 CSV files. Match rows by the complete `Address` string.

## Locations CSV

Required columns:

- `Address`: full address submitted for validation.
- `State`: two-letter state code.
- `Location`: Anytime Mailbox location name.
- `AnytimeMailboxUrl`: source detail page.

The collector also emits `StatePage`, `Street`, `City`, and `Zip`.

## Evidence CSVs

Create one file for Smarty and one for Firstlogic. Required columns:

- `Address`: exactly matches the locations CSV.
- `RDI`: provider's displayed value.
- `CMRA`: provider's displayed value.
- `Status`: `completed` only after a valid provider response. Use `pending`, `429`, `timeout`, `captcha`, or another non-completed value for temporary problems.
- `CheckedAt`: ISO 8601 timestamp including time zone.
- `EvidenceUrl`: public result/reference URL when available; otherwise the provider tool URL.

Optional columns such as `StandardizedAddress` and `Notes` may preserve extra evidence.

## Accepted passing values

| Provider | RDI | CMRA |
| --- | --- | --- |
| Smarty | `Residential` | `N` |
| Firstlogic | `Y`, `R`, or `Residential` | `N` |

Comparison is case-insensitive and ignores surrounding spaces. Any other value, missing evidence, or non-completed status does not qualify for the final CSV.
