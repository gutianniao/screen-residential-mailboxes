[CmdletBinding()]
param(
    [string]$OutputPath = (Join-Path (Get-Location) 'anytime-locations.csv'),
    [string]$CacheDirectory = (Join-Path (Get-Location) 'collection-cache'),
    [string[]]$StateSlugs,
    [int]$RetryCount = 3,
    [switch]$Refresh,
    [switch]$SelfTest
)

$ErrorActionPreference = 'Stop'

$DefaultStateSlugs = @(
    'alabama','alaska','arizona','arkansas','california','colorado','connecticut','dc','delaware','florida',
    'georgia','hawaii','idaho','illinois','indiana','iowa','kansas','kentucky','louisiana','maine',
    'maryland','massachusetts','michigan','minnesota','mississippi','missouri','montana','nebraska','nevada',
    'new-hampshire','new-jersey','new-mexico','new-york','north-carolina','north-dakota','ohio','oklahoma',
    'oregon','pennsylvania','rhode-island','south-carolina','south-dakota','tennessee','texas','utah','vermont',
    'virginia','washington','west-virginia','wisconsin','wyoming'
)

function ConvertFrom-AnytimePage {
    param([Parameter(Mandatory)][string]$Html, [Parameter(Mandatory)][string]$StatePage)

    $pattern = @'
(?is)<div[^>]+class=['"][^'"]*theme-location-item[^'"]*['"][^>]*>.*?<h3[^>]+class=['"][^'"]*t-title[^'"]*['"][^>]*>(?<name>.*?)</h3>.*?<div[^>]+class=['"][^'"]*t-addr[^'"]*['"][^>]*>(?<street>.*?)<br\s*/?>(?<citystate>.*?)<br\s*/?>.*?<a[^>]+href=['"](?<detail>/s/[^'"]+)['"]
'@
    foreach ($match in [regex]::Matches($Html, $pattern)) {
        $stripTags = { param($value) [regex]::Replace([System.Net.WebUtility]::HtmlDecode($value), '<[^>]+>', '').Trim() }
        $street = & $stripTags $match.Groups['street'].Value
        $cityStateZip = & $stripTags $match.Groups['citystate'].Value
        $parts = [regex]::Match($cityStateZip, '^(?<city>.*?),\s*(?<state>[A-Z]{2})\s+(?<zip>\d{5}(?:-\d{4})?)$')
        if (-not $parts.Success -or -not $street) { continue }

        [pscustomobject]@{
            StatePage = $StatePage
            Location = (& $stripTags $match.Groups['name'].Value)
            Street = $street
            City = $parts.Groups['city'].Value.Trim()
            State = $parts.Groups['state'].Value
            Zip = $parts.Groups['zip'].Value
            Address = "$street, $cityStateZip"
            AnytimeMailboxUrl = "https://www.anytimemailbox.com$($match.Groups['detail'].Value)"
        }
    }
}

function Get-PageWithRetry {
    param([Parameter(Mandatory)][string]$Uri, [Parameter(Mandatory)][int]$Attempts)
    for ($attempt = 1; $attempt -le [Math]::Max(1, $Attempts); $attempt++) {
        try {
            return (Invoke-WebRequest -UseBasicParsing -Uri $Uri -TimeoutSec 45).Content
        } catch {
            if ($attempt -eq [Math]::Max(1, $Attempts)) { throw }
            Start-Sleep -Seconds ([Math]::Min(10, [Math]::Pow(2, $attempt)))
        }
    }
}

if ($SelfTest) {
    $sample = @'
<div class="theme-location-item"><h3 class="t-title">Sample Center</h3><div class="t-addr">123 Main St<br>Springfield, IL 62701<br></div><a href="/s/sample-center">View</a></div>
'@
    $rows = @(ConvertFrom-AnytimePage -Html $sample -StatePage 'illinois')
    if ($rows.Count -ne 1 -or $rows[0].Address -ne '123 Main St, Springfield, IL 62701' -or $rows[0].State -ne 'IL') {
        throw 'Self-test failed: page parser did not return the expected row.'
    }
    Write-Output 'PASS: collect-anytime-mailbox.ps1'
    exit 0
}

if (-not $StateSlugs -or $StateSlugs.Count -eq 0) { $StateSlugs = $DefaultStateSlugs }
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$CacheDirectory = [System.IO.Path]::GetFullPath($CacheDirectory)
New-Item -ItemType Directory -Force -Path $CacheDirectory | Out-Null

$all = [System.Collections.Generic.List[object]]::new()
foreach ($slug in $StateSlugs) {
    if ($slug -notmatch '^[a-z0-9-]+$') { throw "Invalid state slug: $slug" }
    $cachePath = Join-Path $CacheDirectory "$slug.html"
    if ((Test-Path -LiteralPath $cachePath) -and -not $Refresh) {
        $html = Get-Content -LiteralPath $cachePath -Raw
    } else {
        $uri = "https://www.anytimemailbox.com/l/usa/$slug"
        Write-Verbose "Fetching $uri"
        $html = Get-PageWithRetry -Uri $uri -Attempts $RetryCount
        Set-Content -LiteralPath $cachePath -Value $html -Encoding UTF8
    }

    foreach ($row in @(ConvertFrom-AnytimePage -Html $html -StatePage $slug)) { $all.Add($row) }
    @($all | Sort-Object Address -Unique) | Export-Csv -LiteralPath $OutputPath -NoTypeInformation -Encoding UTF8
}

$result = @($all | Sort-Object Address -Unique)
[pscustomobject]@{ StatesProcessed = $StateSlugs.Count; Locations = $result.Count; OutputPath = $OutputPath; CacheDirectory = $CacheDirectory }
