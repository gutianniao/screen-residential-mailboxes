[CmdletBinding()]
param(
    [string]$LocationsPath,
    [string]$SmartyEvidencePath,
    [string]$FirstlogicEvidencePath,
    [string]$OutputPath = (Join-Path (Get-Location) 'residential-addresses.csv'),
    [switch]$SelfTest
)

$ErrorActionPreference = 'Stop'

function Get-Value {
    param($Row, [string[]]$Names)
    foreach ($name in $Names) {
        $property = $Row.PSObject.Properties[$name]
        if ($null -ne $property -and $null -ne $property.Value) { return [string]$property.Value }
    }
    return ''
}

function Get-Key { param($Row) (Get-Value $Row @('Address','address')).Trim().ToUpperInvariant() }

function Test-Completed {
    param($Row)
    $status = (Get-Value $Row @('Status','status')).Trim()
    return $status -match '^(?i:complete|completed|success|ok)$'
}

function New-EvidenceMap {
    param([object[]]$Rows)
    $map = @{}
    foreach ($row in $Rows) {
        $key = Get-Key $row
        if ($key -and (Test-Completed $row)) { $map[$key] = $row }
    }
    return $map
}

function Select-VerifiedRows {
    param([object[]]$Locations, [object[]]$Smarty, [object[]]$Firstlogic)
    $smartyMap = New-EvidenceMap $Smarty
    $firstlogicMap = New-EvidenceMap $Firstlogic

    foreach ($location in $Locations) {
        $key = Get-Key $location
        if (-not $smartyMap.ContainsKey($key) -or -not $firstlogicMap.ContainsKey($key)) { continue }
        $s = $smartyMap[$key]
        $f = $firstlogicMap[$key]
        $smartyRdi = (Get-Value $s @('RDI','rdi')).Trim()
        $smartyCmra = (Get-Value $s @('CMRA','cmra','dpv_cmra')).Trim()
        $firstlogicRdi = (Get-Value $f @('RDI','rdi','rdi_indicator')).Trim()
        $firstlogicCmra = (Get-Value $f @('CMRA','cmra','cmra_flag')).Trim()

        $smartyPass = $smartyRdi -match '^(?i:Residential)$' -and $smartyCmra -match '^(?i:N)$'
        $firstlogicPass = $firstlogicRdi -match '^(?i:Y|R|Residential)$' -and $firstlogicCmra -match '^(?i:N)$'
        if (-not ($smartyPass -and $firstlogicPass)) { continue }

        [pscustomobject]@{
            State = Get-Value $location @('State','state')
            Location = Get-Value $location @('Location','Name','location','name')
            Address = Get-Value $location @('Address','address')
            AnytimeMailboxUrl = Get-Value $location @('AnytimeMailboxUrl','SourceUrl','anytime_mailbox_url')
            SmartyRDI = $smartyRdi
            SmartyCMRA = $smartyCmra
            SmartyCheckedAt = Get-Value $s @('CheckedAt','checked_at')
            SmartyEvidenceUrl = Get-Value $s @('EvidenceUrl','evidence_url')
            FirstlogicRDI = $firstlogicRdi
            FirstlogicCMRA = $firstlogicCmra
            FirstlogicCheckedAt = Get-Value $f @('CheckedAt','checked_at')
            FirstlogicEvidenceUrl = Get-Value $f @('EvidenceUrl','evidence_url')
        }
    }
}

if ($SelfTest) {
    $locations = @(
        [pscustomobject]@{ State='IL'; Location='Pass'; Address='1 Main St, A, IL 60000'; AnytimeMailboxUrl='https://example.test/1' },
        [pscustomobject]@{ State='IL'; Location='Fail'; Address='2 Main St, A, IL 60000'; AnytimeMailboxUrl='https://example.test/2' },
        [pscustomobject]@{ State='IL'; Location='Pending'; Address='3 Main St, A, IL 60000'; AnytimeMailboxUrl='https://example.test/3' }
    )
    $smarty = @(
        [pscustomobject]@{ Address=$locations[0].Address; RDI='Residential'; CMRA='N'; Status='completed' },
        [pscustomobject]@{ Address=$locations[1].Address; RDI='Residential'; CMRA='N'; Status='completed' },
        [pscustomobject]@{ Address=$locations[2].Address; RDI='Residential'; CMRA='N'; Status='429' }
    )
    $firstlogic = @(
        [pscustomobject]@{ Address=$locations[0].Address; RDI='Y'; CMRA='N'; Status='success' },
        [pscustomobject]@{ Address=$locations[1].Address; RDI='N'; CMRA='N'; Status='success' },
        [pscustomobject]@{ Address=$locations[2].Address; RDI='Y'; CMRA='N'; Status='success' }
    )
    $rows = @(Select-VerifiedRows -Locations $locations -Smarty $smarty -Firstlogic $firstlogic)
    if ($rows.Count -ne 1 -or $rows[0].Address -ne $locations[0].Address) {
        throw 'Self-test failed: strict double-verification filter returned an unexpected result.'
    }
    Write-Output 'PASS: filter-verified-results.ps1'
    exit 0
}

foreach ($required in @('LocationsPath','SmartyEvidencePath','FirstlogicEvidencePath')) {
    if (-not (Get-Variable -Name $required -ValueOnly)) { throw "-$required is required unless -SelfTest is used." }
}

$locations = @(Import-Csv -LiteralPath $LocationsPath)
$smarty = @(Import-Csv -LiteralPath $SmartyEvidencePath)
$firstlogic = @(Import-Csv -LiteralPath $FirstlogicEvidencePath)
$verified = @(Select-VerifiedRows -Locations $locations -Smarty $smarty -Firstlogic $firstlogic | Sort-Object Address -Unique)
$verified | Export-Csv -LiteralPath $OutputPath -NoTypeInformation -Encoding UTF8
$smartyCompleted = New-EvidenceMap $smarty
$firstlogicCompleted = New-EvidenceMap $firstlogic

[pscustomobject]@{
    SourceLocations = $locations.Count
    SmartyCompleted = $smartyCompleted.Count
    FirstlogicCompleted = $firstlogicCompleted.Count
    Verified = $verified.Count
    OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
}
